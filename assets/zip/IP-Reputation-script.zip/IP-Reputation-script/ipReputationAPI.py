import requests
import time

with open("iteration-ip.txt", "r") as ip_file:  # Grab the IP addresses in the file
    IPs = []
    IPs = ip_file.read().split("\n")            # Split each IP address by a newline character

for i in range(len(IPs)):     # loop

    url = "https://www.virustotal.com/api/v3/ip_addresses/" + IPs[i]    # URL for the needed API + the current IP

    headers = {
        "accept": "application/json",
        "x-apikey": "<API-KEY>"     # Add in your API key
    }

    response = requests.get(url, headers=headers)       # Send the response

    print(IPs[i], " Had a response code of ", response)     # feedback in terminal

    time.sleep(0.5)       # Make sure the API doesnt block us for too many requests

    filename = IPs[i] + ".json"         # If you want the json to be human readable, in vscode or codium
                                        # use the hotkey CTRL + SHIFT + R to format it
    with open(filename, "w") as f:
        f.write(str(response.text))             # save the output in a json file named with the IP
